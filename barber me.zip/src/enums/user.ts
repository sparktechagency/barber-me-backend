export enum USER_ROLES {
    ADMIN = 'ADMIN',
    SUPER_ADMIN = 'SUPER_ADMIN',
    CUSTOMER = 'CUSTOMER',
    BARBER = 'BARBER',
}