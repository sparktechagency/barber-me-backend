export type IErrorMessage = {
    path: string | number;
    message: string;
};